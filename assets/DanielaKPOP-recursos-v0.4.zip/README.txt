DanielaKPOP v0.4 — Recursos del usuario

Copia el contenido de la carpeta public/ a public/ en el repositorio GitHub DanielaKPOP.
Archivo musical: public/assets/studio-song.mp3. Sonará al tocar la minicadena en el estudio y se detendrá al salir.
Modelos alimenticios Kenney Food Kit (CC0). Modelos interiores Quaternius Ultimate House Interior Pack (CC0 según los archivos aportados). Partículas Kenney Particle Pack (CC0).
No se incluyen animaciones de Mixamo porque no se han adjuntado archivos.
